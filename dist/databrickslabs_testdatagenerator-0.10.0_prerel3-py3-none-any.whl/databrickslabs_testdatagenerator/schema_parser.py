# See the License for the specific language governing permissions and
# limitations under the License.
#
from pyspark.sql.types import LongType, FloatType, IntegerType, StringType, DoubleType, BooleanType, ShortType, \
    StructType, StructField, TimestampType, DateType, DecimalType, ByteType
import re


class SchemaParser(object):
    """" SchemaParser class

        Creates pyspark SQL datatype from string
    """
    _match_precision_only = re.compile("decimal\s*\(\s*([0-9]+)\s*\)")
    _match_precision_and_scale = re.compile("decimal\s*\(\s*([0-9]+)\s*,\s*([0-9]+)\s*\)")

    @classmethod
    def parseDecimal(cls, str):
        """ parse a decimal specifier

        :param str: - decimal specifier string such as `decimal(19,4)`, `decimal` or `decimal(10)`
        :returns: DecimalType instance for parsed result
        """
        m = cls._match_precision_only.search(str)
        if m:
            return DecimalType(int(m.group(1)))

        m = cls._match_precision_and_scale.search(str)
        if m:
            return DecimalType(int(m.group(1)), int(m.group(2)))

        return DecimalType()

    @classmethod
    def columnTypeFromString(cls, type_string):
        """ Generate a Spark SQL data type from a string

        :param type_string: String representation of SQL type such as 'integer' etc
        :returns: Spark SQL type
        """
        assert type_string is not None

        s = type_string.strip().lower()
        if s == "string" or s == "varchar" or s == "char" or s == "nvarchar":
            return StringType()
        elif s == "int" or s == "integer":
            return IntegerType()
        elif s == "bigint" or s == "long":
            return LongType()
        elif s == "bool" or s == "boolean":
            return BooleanType()
        elif s == "timestamp" or s == "datetime":
            return TimestampType()
        elif s.startswith("decimal") or s.startswith("number"):
            return cls.parseDecimal(s)
        elif s == "double":
            return DoubleType()
        elif s == "float":
            return FloatType()
        elif s == "date":
            return DateType()
        elif s == "short":
            return ShortType()
        elif s == "byte":
            return ByteType()
        else:
            return s

    @classmethod
    def parseCreateTable(cls, sparkSession, source_schema):
        """ Parse a schema from a schema string

            :param source_schema: should be a table definition minus the create table statement
            :returns: Spark SQL schema instance
        """
        assert (source_schema is not None)
        assert (sparkSession is not None)
        lines = [x.strip() for x in source_schema.split("\n") if x is not None]
        table_defn = " ".join(lines)

        # get table name from s
        table_name_match = re.search(r"^\screate\s*(temporary\s*)?table\s*([a-zA-Z0-9_]*)\s*(\(.*)$", table_defn)

        if table_name_match:
            table_name = table_name_match.group(2)
            table_body = table_name_match.group(3)
        else:
            raise ValueError("Table name could not be found")

        print('table name ', table_name)

        sparkSession.sql("create temporary table {}{}using csv".format(table_name, table_body))

        result = sparkSession.sql("select * from {}".format(table_name))
        result.printSchema()
        result_schema = result.schema

        sparkSession.sql("drop table {}".format(table_name))

        return result_schema
