# See the License for the specific language governing permissions and
# limitations under the License.
#

"""
This module defines the Preconditions class. This is still a work in progress.
"""

class Preconditions:

    @classmethod
    def checkArgumen(cls, arg, msg=None):
        pass

    @classmethod
    def checkNonNull(cls, arg,msg=None):
        pass

    @classmethod
    def checkNonEmpty(cls, arg, msg=None):
        pass

    @classmethod
    def checkIndexInRange(cls, arg, msg=None, start=0, end=None):
        pass

    @classmethod
    def checkState(cls, arg, msg=None ):
        pass

